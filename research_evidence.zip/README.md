# Groundwater PINN research compendium

Start with `RESEARCH_REPORT.md` for chronological research motivation, exact results, research caveats, readings, full code listings, and future direction. Every phase has runnable source or its original Colab notebook, and recorded data/figures in `results/`.
