# Controlled PINN Loss-Weight and Convergence Investigation

**Date:** October 2026 | **Status:** completed exploratory computational benchmark; no theoretical convergence guarantee.

## Question
At groundwater conductivity contrast 100:1, are inaccurate PINN predictions primarily associated with insufficient optimization budget, poor loss balancing, or spatially heterogeneous PDE conditioning?

## Setup
Solve `-(k(x)h'(x))'=1`, `h(0)=1`, `h(1)=0`, with `k(x)=exp(-log(100)*sigmoid((x-0.5)/0.04))`.

The reference hydraulic head and Darcy flux follow from integrating `q'(x)=1` and `q=-k h'` and satisfying boundary data. **This smooth-transition 1D synthetic case is not a field-scale groundwater model and has no sharp material interface**.

Neural net: tanh 1–32–32–1; 80 interior points; Adam learning rate 0.002. Paired seeds 0,1,2; snapshots after 250, 500, 1200, 2500 epochs. Training objective `L_PDE+w L_BC`. Fixed weights 0.1,1,10,100. Adaptive heuristic weights PDE and boundary losses using the ratio of their gradient norms, clipped to [0.1,1000], smoothed (`w = 0.9w + 0.1 target`) and updated at epoch 1 and every 50 steps.

Evaluation metrics: relative L2 head error against 1001-point high-resolution integral reference; RMSE of predicted flux against exact `q(x)=C+x`; finite-grid flux conservation residual `RMSE(dq/dx-1)`; boundary error. Flux derivative was evaluated by finite differences, so conservation residual incorporates numerical differentiation error.

## Results: median of three seeds at 2500 epochs

| Method | Median relative L2 head error | Median flux-reference RMSE | Median flux conservation RMSE |
|---|---:|---:|---:|
| fixed_0.1 | 0.002759 | 0.003671 | 0.034207 |
| fixed_1.0 | 0.012710 | 0.002888 | 0.069096 |
| adaptive | 0.065814 | 0.016791 | 0.150531 |
| fixed_10.0 | 0.117370 | 0.026835 | 0.211423 |
| fixed_100.0 | 0.478162 | 0.175107 | 0.537128 |

## Interpretation
- Untuned fixed weight 1 was not the strongest fixed baseline: weight 0.1 gave much better head error and conservation residual at the same 2500-epoch budget.
- Adaptive weighting was less accurate than the best tested fixed weight; no general superiority claim is justified.
- Fixed weight 1 slightly improved the *flux-reference* RMSE over fixed weight 0.1 by median, illustrating that different error metrics need not rank models identically.
- Earlier experiments showed additional training could improve strongly at 100:1, but **this sweep only provides checkpoints through 2500 epochs**. It does not isolate PDE conditioning from optimizer or architecture effects.
- This is not a causal decomposition of error sources. Changing weight changes optimization trajectories, and conductivity contrast was held constant during this sweep. To isolate heterogeneity, repeat the weight sweep at contrasts 1 and 10; to isolate optimization budget, extend each method until a comparable stopping criterion and compare compute cost.

## Limitations and next steps
Three seeds only; fixed weights sparsely sampled, not optimized; adaptive heuristic is not a leading published adaptive strategy; no LBFGS or hard boundary condition baseline; no replicate statistical inference; no real geological data or inverse conductivity inference; 1D smooth coefficient, not a discontinuous layer or 2D/3D subsurface. For a stronger study, benchmark 0.01,0.03,0.1,0.3,1 with 10+ seeds, compare fixed and adaptive on equal wall-clock budgets, test hard boundary constraints, measure local residuals and conservation, and then tackle discontinuous layers with explicit interface continuity and flux conditions.

## Reproducibility
`groundwater_loss_sweep.py` is the runnable CLI code. Use `python groundwater_loss_sweep.py --epochs 2500 --seeds 0 1 2 --weights 0.1 1 10 100 --out ./results`. `Groundwater_Loss_Convergence_Colab.ipynb` runs the same script logic in Colab. The zip includes metrics, training history, four figures, config, source, and this report.
