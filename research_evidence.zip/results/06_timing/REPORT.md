# Groundwater PINN: Timing of Boundary-Loss Interventions

## Study design
Steady synthetic 1D heterogeneous groundwater PDE, conductivity contrast 100:1 (smooth transition). Ten initialization seeds (0–9), each trained with fixed boundary weight 1 to checkpoints of 250, 1000, and 2500 Adam updates. At every checkpoint, both network parameters and the Adam optimizer state were cloned into three strategies: fixed boundary weight 0.1, fixed weight 1 (control), or gradient-ratio adaptive weight initialized at 1. All three were trained for **400 further updates**, giving identical continuation budgets *within each checkpoint* (but different total optimization steps across checkpoints). This is a prospective controlled intervention in the simulation, not a random trial involving physical systems.

## Primary finding
The median hydraulic-head error of fixed 1 was lowest at all three tested checkpoints. Fixed 0.1 reduced median flux conservation error at certain checkpoints but often worsened boundary satisfaction and median head accuracy. Gradient-ratio adaptive generally did not improve median head accuracy over fixed 1. Final gradient cosine values may be highly negative but should not be interpreted as independently establishing the causal mechanism.

## Interpretation caveats
The underlying model is a smooth-transition one-dimensional manufactured groundwater benchmark with a known numerical truth, not field measurements. Adaptive weighting may use additional gradient evaluations, so an equal-step experiment is not an equal-runtime experiment. The initial fixed-1 training history favors its own trajectory; comparison is fair for the *intervention effect conditional on that training history*, not universally optimal training from scratch. Increasing checkpoint size also increases total training updates, so raw errors across checkpoints cannot isolate timing without using paired within-checkpoint contrasts. Only three checkpoints and 10 seeds, one architecture, one conductivity contrast, and 400-step post-intervention horizon were examined. No universal convergence theorem or new algorithm is claimed.

## Files
- groundwater_timing_study.py: executable source, supports --start for chunked seeds.
- measurements.csv: checkpoint-level outcomes for all 90 branches (including initial, midpoint, final).
- summary.csv: median outcomes by timing and weighting strategy.
- paired_ratios.csv: within-seed, within-checkpoint paired head-error ratios.
- three figure PNGs.

## Final medians

|   checkpoint | mode      |   seeds |    head |    flux |      bc |   cosine |   weight |
|-------------:|:----------|--------:|--------:|--------:|--------:|---------:|---------:|
|          250 | adaptive  |      10 | 0.17857 | 0.26243 | 0.01474 | -0.96241 |  1.50024 |
|          250 | fixed_0.1 |      10 | 0.25394 | 0.30006 | 0.23330 | -0.93779 |  0.10000 |
|          250 | fixed_1   |      10 | 0.17745 | 0.26173 | 0.02961 | -0.80443 |  1.00000 |
|         1000 | adaptive  |      10 | 0.13953 | 0.23777 | 0.01863 | -0.99527 |  1.55360 |
|         1000 | fixed_0.1 |      10 | 0.15832 | 0.21664 | 0.22126 | -0.97517 |  0.10000 |
|         1000 | fixed_1   |      10 | 0.13743 | 0.23720 | 0.02520 | -0.99169 |  1.00000 |
|         2500 | adaptive  |      10 | 0.01053 | 0.06156 | 0.00142 | -0.80843 |  3.12415 |
|         2500 | fixed_0.1 |      10 | 0.01465 | 0.06203 | 0.02056 | -0.41183 |  0.10000 |
|         2500 | fixed_1   |      10 | 0.00961 | 0.06595 | 0.00266 | -0.28362 |  1.00000 |

## Paired wins versus fixed 1 (out of 10)

|   checkpoint |   fixed01_better_than_fixed1 |   adaptive_better_than_fixed1 |
|-------------:|-----------------------------:|------------------------------:|
|          250 |                            0 |                             2 |
|         1000 |                            0 |                             3 |
|         2500 |                            2 |                             1 |
