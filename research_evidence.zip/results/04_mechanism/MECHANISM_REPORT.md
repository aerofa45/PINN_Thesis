# Why did a 0.1 boundary weight beat adaptive weighting?

## Design
Steady 1D heterogeneous groundwater equation with conductivity contrast 100:1. Same tanh 2x32 network, 80 collocation points, Adam lr 0.002, 2500 epochs and matched seeds 0,1,2. Examined a fixed 0.1 weight, original gradient-ratio adaptive heuristic, and a version initialized at 0.1 and capped at 1.0. An adaptive cap of 0.1 is mathematically equivalent to fixed 0.1 in this implementation; it is a sanity check, **not** independent corroboration.

## Results
Median over three seeds at 2500 epochs:

| Method | Rel. L2 head error | Flux conservation RMSE | Median final weight |
|---|---:|---:|---:|
| Fixed 0.1 | 0.002759 | 0.034207 | 0.1 |
| Adaptive original | 0.065814 | 0.150531 | 4.361 |
| Adaptive capped at 1 | 0.016673 | 0.062331 | 0.855 |
| Adaptive capped at 0.1 | 0.002759 | 0.034207 | 0.1 |

Original adaptive rule's final weights by seed were 11.50, 3.56, 4.36, far above 0.1. Capping at 1 lowered the median relative head error, but was unstable across seeds (relative L2 errors 0.00186, 0.13596, 0.01667). The results support an association between overemphasis on boundary loss and poorer accuracy; they do **not** establish that weight growth is the only causal mechanism.

## Why the gradient ratio may mislead
The adaptive rule uses norms of parameter gradients of the PDE residual and boundary MSE. As boundary error approaches zero, the boundary gradient norm can become small, leading to a large ratio and an increased boundary weight. In this experiment, the original adaptive weight increased during training, despite boundary conditions being already well satisfied. Overweighting boundary matching can divert optimization updates away from satisfying the governing differential equation in the interior. The claim about diverted updates is a plausible mechanism, **not yet directly proven** by a gradient-alignment or controlled weight-intervention analysis.

## Interpretation limits
- 3 random seeds only; no robust statistical inference.
- One smooth 1D transition rather than discontinuous strata or real aquifer data.
- Fixed 0.1 was selected after seeing the prior sweep, so the present ablation is exploratory and selection-biased.
- Weight clipping changes both trajectory and optimizer dynamics.
- No wall-time controlled or gradient-cosine-similarity comparisons.
- Adaptive algorithm is a simple heuristic, not a best-in-class published strategy.
- We cannot claim an original PINN loss balancing algorithm or a theoretical convergence result.

## Next decisive test
Hold the original adaptive weight trajectory fixed but scale it down, or intervene midway in training on the same checkpoint by switching to w=0.1, w=1, or its original adaptive value. Log per-term gradient norms and gradient cosine similarity as well as boundary and PDE residual error in high- and low-conductivity regions. Repeat for >=10 fresh seeds. This would better isolate causality.
