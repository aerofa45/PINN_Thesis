# Groundwater PINN Project 2 — Experiment Report (October 2026)

## Research question
How does increased conductivity contrast affect training accuracy of fixed-loss and gradient-balanced physics-informed neural networks?

## Problem and methods
Steady 1D synthetic groundwater flow: `-(k(x)h′(x))′=1`, `h(0)=1`, `h(1)=0`. `k(x)=exp[-log(C)*sigmoid((x-.5)/.04)]`, C=1,10,100. The interface is **smooth** (not piecewise discontinuous). A high-resolution quadrature of the analytic flux relationship supplies a reference solution. Each PINN: tanh 1-32-32-1, 80 interior collocation points, Adam with lr=0.002. Fixed baseline loss `L_PDE+L_BC`; adaptive uses a gradient-norm-ratio boundary weight, clipped to [0.1,1000], with smoothing and 50-epoch updates.

## Main results: 1200 epochs, 3 paired seeds
| Conductivity ratio | Fixed median relative L2 | Adaptive median relative L2 |
|---|---:|---:|
| 1:1 | 0.000057 | 0.000047 |
| 10:1 | 0.000716 | 0.001751 |
| 100:1 | 0.142405 | 0.140363 |

The training difficulty increases markedly at high contrast under this budget. Adaptive loss weighting is **not consistently beneficial** (worse median at 10:1). These are 3-seed descriptive statistics, not statistically established population effects.

## Diagnostic: 5000 epochs at 100:1 (two paired seeds)
| Seed | Fixed relative L2 | Adaptive relative L2 |
|---|---:|---:|
| 0 | 0.005747 | 0.020584 |
| 1 | 0.001248 | 0.001828 |

Longer training decreased error considerably. This limits the interpretation: the large 1200-epoch error is at least partly a training-budget / optimization issue rather than proof that PINNs are unable to solve heterogeneous equations.

## Tentative research statement
At a fixed 1200-epoch budget, this 1D PINN benchmark shows large loss of accuracy when hydraulic conductivity contrast rises to 100:1. A simple adaptive boundary-loss weight does not consistently improve accuracy. A 5000-epoch diagnostic strongly reduces errors, indicating sensitivity to optimization budget. Better-controlled experiments are needed to distinguish conditioning, architecture, weighting, and physical heterogeneity effects.

## Limitations and next experiments
- Only 3 seeds (1200 epochs) and 2 seeds (5000 epochs); single architecture and optimizer.
- Fixed boundary weight of 1 was not tuned. Compare at least w=0.1,1,10,100.
- Equal epochs alone does not equalize computation cost; adaptive gradient calculation has extra overhead.
- Need flux error, spatial residual plots, reference convergence test, and physical mass balance.
- Smooth transition is not a sharp geological interface; discontinuities need interface conditions.
- No observational data, 2D/3D flow, inverse analysis, or convergence theory yet.

## Interpretation for PhD portfolio
This is a completed **reproducible pilot**, not a new PINN algorithm or evidence for a general theorem. Follow-up work should focus on a controlled study of failure modes, tuning, conductivity contrasts, and flux conservation.
