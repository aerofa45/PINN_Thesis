"""Controlled 100:1 conductivity PINN loss-weight and convergence benchmark.
Run: python groundwater_loss_sweep.py --epochs 2500 --seeds 0 1 2
"""
import argparse, json, math, time, random
from pathlib import Path
import numpy as np, pandas as pd, torch
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser=argparse.ArgumentParser()
parser.add_argument('--epochs',type=int,default=2500)
parser.add_argument('--seeds',type=int,nargs='+',default=[0,1,2])
parser.add_argument('--weights',type=float,nargs='+',default=[0.1,1.,10.,100.])
parser.add_argument('--out',default='/mnt/data/groundwater_loss_sweep_results')
args=parser.parse_args()
torch.set_num_threads(1)
OUT=Path(args.out); OUT.mkdir(exist_ok=True,parents=True)
CONTRAST=100.; WIDTH=32; N_COL=80; LR=0.002; TRANS=0.04; SOURCE=1.; DEVICE='cpu'
BC_LEFT=1.; BC_RIGHT=0.; X=np.linspace(0.,1.,1001)
CHECKPOINTS=sorted(set([n for n in (250,500,1200,args.epochs) if n<=args.epochs]))

def knp(x):
 s=1/(1+np.exp(-np.clip((np.asarray(x)-.5)/TRANS,-50,50)))
 return np.exp(-math.log(CONTRAST)*s)
def kt(x):
 s=torch.sigmoid((x-.5)/TRANS);k=torch.exp(-math.log(CONTRAST)*s)
 return k,-math.log(CONTRAST)/TRANS*s*(1-s)*k

def reference(x):
 xx=np.linspace(0,1,40001); k=knp(xx); inv=1/k
 a=np.trapezoid(inv,xx); b=np.trapezoid(xx*inv,xx)
 c=(BC_LEFT-BC_RIGHT-SOURCE*b)/a
 d=(c+SOURCE*xx)*inv
 cumulative=np.r_[0,np.cumsum((d[1:]+d[:-1])*.5*np.diff(xx))]
 return BC_LEFT-np.interp(x,xx,cumulative),c
TRUE,C=reference(X)
class PINN(torch.nn.Module):
 def __init__(self):
  super().__init__();self.net=torch.nn.Sequential(torch.nn.Linear(1,WIDTH),torch.nn.Tanh(),torch.nn.Linear(WIDTH,WIDTH),torch.nn.Tanh(),torch.nn.Linear(WIDTH,1))
 def forward(self,x):return self.net(x)
def seed_all(s): random.seed(s);np.random.seed(s);torch.manual_seed(s)
def grad_norm(loss,model):
 g=torch.autograd.grad(loss,tuple(model.parameters()),retain_graph=True,allow_unused=True)
 return math.sqrt(sum(float((v.detach()**2).sum()) for v in g if v is not None)+1e-24)
def evaluate(model,seed,method,epoch,w,elapsed):
 xt=torch.tensor(X[:,None],dtype=torch.float32,requires_grad=True)
 pred=model(xt)
 hx=torch.autograd.grad(pred,xt,torch.ones_like(pred),create_graph=False)[0]
 pp=pred.detach().numpy().ravel(); hx=hx.detach().numpy().ravel()
 q=-knp(X)*hx
 # PDE is q'(x)=SOURCE, so q_expected(x)=C+SOURCE*x.
 qref=C+SOURCE*X
 # Offset-invariant flux conservation: q(x)-q(0) should equal SOURCE*x.
 flux_increment_error=float(np.sqrt(np.mean((q-q[0]-SOURCE*X)**2)))
 flux_reference_rmse=float(np.sqrt(np.mean((q-qref)**2)))
 # Conservation interior discrepancy measured through q' - f on dense grid.
 qprime=np.gradient(q,X,edge_order=2)
 conservation_rmse=float(np.sqrt(np.mean((qprime[1:-1]-SOURCE)**2)))
 return {'seed':seed,'method':method,'epochs':epoch,'weight':w,'elapsed_sec':elapsed,
  'relative_l2':float(np.linalg.norm(pp-TRUE)/np.linalg.norm(TRUE)),
  'max_absolute_error':float(np.max(np.abs(pp-TRUE))),
  'bc_max_error':float(max(abs(pp[0]-BC_LEFT),abs(pp[-1]-BC_RIGHT))),
  'flux_reference_rmse':flux_reference_rmse,
  'flux_increment_rmse':flux_increment_error,
  'flux_conservation_rmse':conservation_rmse},pp,q

def train(seed,method):
 seed_all(seed);model=PINN();opt=torch.optim.Adam(model.parameters(),lr=LR)
 x=torch.linspace(0,1,N_COL+2)[1:-1].reshape(-1,1).detach().requires_grad_(True)
 xb=torch.tensor([[0.],[1.]]);bt=torch.tensor([[BC_LEFT],[BC_RIGHT]])
 w=1. if method=='adaptive' else float(method.replace('fixed_',''))
 start=time.perf_counter(); snapshots=[]; histories=[]; preds={}
 for epoch in range(1,args.epochs+1):
  opt.zero_grad(set_to_none=True)
  y=model(x);dy=torch.autograd.grad(y,x,torch.ones_like(y),create_graph=True)[0]
  d2y=torch.autograd.grad(dy,x,torch.ones_like(dy),create_graph=True)[0]
  k,kprime=kt(x);res=-(k*d2y+kprime*dy)-SOURCE
  pde=(res**2).mean();bc=((model(xb)-bt)**2).mean()
  if method=='adaptive' and (epoch==1 or epoch%50==0):
   gp=grad_norm(pde,model);gb=grad_norm(bc,model)
   w=.9*w+.1*float(np.clip(gp/(gb+1e-12),.1,1000.))
  loss=pde+w*bc;loss.backward();opt.step()
  if epoch in CHECKPOINTS:
   m,p,q=evaluate(model,seed,method,epoch,w,time.perf_counter()-start);snapshots.append(m)
   preds[(seed,method,epoch)]=(p,q)
  if epoch==1 or epoch%100==0:
   histories.append({'seed':seed,'method':method,'epoch':epoch,'pde_loss':float(pde.detach()),'bc_loss':float(bc.detach()),'weight':w})
 return snapshots,histories,preds

allm=[]; allh=[]; predictions={}; methods=['fixed_'+str(x) for x in args.weights]+['adaptive']
for seed in args.seeds:
 for method in methods:
  m,h,p=train(seed,method);allm+=m;allh+=h;predictions.update(p)
  print('seed',seed,method,'final', {k:round(m[-1][k],6) for k in ['relative_l2','flux_reference_rmse','flux_conservation_rmse','elapsed_sec']},flush=True)
metrics=pd.DataFrame(allm);history=pd.DataFrame(allh)
metrics.to_csv(OUT/'metrics.csv',index=False);history.to_csv(OUT/'history.csv',index=False)
final=metrics[metrics.epochs==args.epochs]
summary=final.groupby('method').agg(median_l2=('relative_l2','median'),min_l2=('relative_l2','min'),max_l2=('relative_l2','max'),median_flux_rmse=('flux_reference_rmse','median'),median_conservation_rmse=('flux_conservation_rmse','median'),median_seconds=('elapsed_sec','median')).sort_values('median_l2')
summary.to_csv(OUT/'summary.csv')
print('\nSUMMARY\n'+summary.to_string(),flush=True)
fig,ax=plt.subplots(figsize=(8,4.5))
for method in methods:
 sub=metrics[metrics.method==method].groupby('epochs')['relative_l2'].median()
 ax.plot(sub.index,sub.values,'-o',label=method)
ax.set(xlabel='Training epochs',ylabel='Median relative L2 head error',title='100:1 contrast — convergence vs loss weight');ax.set_yscale('log');ax.legend(ncol=2);ax.grid(alpha=.25);fig.tight_layout();fig.savefig(OUT/'error_convergence.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.5))
for method in methods:
 sub=metrics[metrics.method==method].groupby('epochs')['flux_conservation_rmse'].median()
 ax.plot(sub.index,sub.values,'-o',label=method)
ax.set(xlabel='Training epochs',ylabel='Median RMSE of dq/dx - source',title='100:1 contrast — flux conservation');ax.set_yscale('log');ax.legend(ncol=2);ax.grid(alpha=.25);fig.tight_layout();fig.savefig(OUT/'flux_conservation.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.5));ax.plot(X,TRUE,'k--',label='Reference',linewidth=2)
for method in methods:
 pp,q=predictions[(args.seeds[0],method,args.epochs)]
 ax.plot(X,pp,label=method,alpha=.8)
ax.set(xlabel='x',ylabel='Hydraulic head',title=f'100:1 contrast — seed {args.seeds[0]}');ax.legend(ncol=2,fontsize=8);ax.grid(alpha=.25);fig.tight_layout();fig.savefig(OUT/'solution_comparison.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.5));ax.plot(X,C+SOURCE*X,'k--',label='Exact Darcy flux')
for method in methods:
 pp,q=predictions[(args.seeds[0],method,args.epochs)]
 ax.plot(X,q,label=method,alpha=.75)
ax.set(xlabel='x',ylabel='Darcy flux q(x)',title=f'100:1 contrast — flux profile, seed {args.seeds[0]}');ax.legend(ncol=2,fontsize=8);ax.grid(alpha=.25);fig.tight_layout();fig.savefig(OUT/'flux_profiles.png',dpi=160);plt.close(fig)
(OUT/'config.json').write_text(json.dumps({'contrast':CONTRAST,'conductivity_transition_width':TRANS,'source':SOURCE,'boundary':[BC_LEFT,BC_RIGHT],'seeds':args.seeds,'weights':args.weights,'epochs':args.epochs,'snapshots':CHECKPOINTS,'width':WIDTH,'layers':2,'n_collocation':N_COL,'learning_rate':LR,'adaptive':'gradient ratio, clipped [0.1,1000], exponential smoothing 0.1, updated every 50 epochs','reference':'integrated exact flux identity'},indent=2))
