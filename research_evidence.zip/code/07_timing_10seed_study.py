"""Paired checkpoint intervention study: groundwater PINN at conductivity contrast 100.
Each seed yields checkpoints at 250, 1000, 2500 epochs under fixed boundary weight 1.
For each checkpoint, clone model AND optimizer and branch for --branch steps.
Usage: python groundwater_timing_study.py --seeds 10 --branch 400
"""
import argparse,copy,math,random,time
from pathlib import Path
import numpy as np,pandas as pd,torch
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,default=10);p.add_argument('--start',type=int,default=0);p.add_argument('--branch',type=int,default=400);p.add_argument('--out',default='/mnt/data/groundwater_timing_results');a=p.parse_args()
torch.set_num_threads(1);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
C=100.;T=.04;XX=np.linspace(0,1,1001)
def kn(v):
 s=1/(1+np.exp(-np.clip((np.asarray(v)-.5)/T,-50,50)));return np.exp(-math.log(C)*s)
def kt(v):
 s=torch.sigmoid((v-.5)/T);k=torch.exp(-math.log(C)*s);return k,-math.log(C)/T*s*(1-s)*k
x_dense=np.linspace(0,1,40001);inv=1/kn(x_dense);c=(1-np.trapezoid(x_dense*inv,x_dense))/np.trapezoid(inv,x_dense)
ref=1-np.interp(XX,x_dense,np.r_[0,np.cumsum((c+x_dense[1:])*inv[1:]*np.diff(x_dense)/2+(c+x_dense[:-1])*inv[:-1]*np.diff(x_dense)/2)])
class Net(torch.nn.Module):
 def __init__(self):
  super().__init__();self.net=torch.nn.Sequential(torch.nn.Linear(1,32),torch.nn.Tanh(),torch.nn.Linear(32,32),torch.nn.Tanh(),torch.nn.Linear(32,1))
 def forward(self,z):return self.net(z)
x=torch.linspace(0,1,82)[1:-1,None].detach().requires_grad_(True);xb=torch.tensor([[0.],[1.]]);yb=torch.tensor([[1.],[0.]])
def losses(net):
 h=net(x);hp=torch.autograd.grad(h,x,torch.ones_like(h),create_graph=True)[0];hpp=torch.autograd.grad(hp,x,torch.ones_like(hp),create_graph=True)[0];k,kp=kt(x)
 return (-(k*hpp+kp*hp)-1).square().mean(),(net(xb)-yb).square().mean()
def grads(pde,bc,net):
 ps=list(net.parameters());ga=torch.autograd.grad(pde,ps,retain_graph=True,allow_unused=True);gb=torch.autograd.grad(bc,ps,retain_graph=True,allow_unused=True);va=torch.cat([(g.detach() if g is not None else torch.zeros_like(param)).flatten() for g,param in zip(ga,ps)]);vb=torch.cat([(g.detach() if g is not None else torch.zeros_like(param)).flatten() for g,param in zip(gb,ps)]);na=va.norm().item();nb=vb.norm().item()
 return na,nb,torch.dot(va,vb).item()/(na*nb+1e-20)
def measure(net):
 with torch.enable_grad():
  z=torch.tensor(XX[:,None],dtype=torch.float32,requires_grad=True);y=net(z);hp=torch.autograd.grad(y,z,torch.ones_like(y))[0].detach().numpy().ravel();pred=y.detach().numpy().ravel()
 flux=-kn(XX)*hp;return dict(head_l2=float(np.linalg.norm(pred-ref)/np.linalg.norm(ref)),flux_cons=float(np.mean((np.gradient(flux,XX,edge_order=2)[1:-1]-1)**2)**.5),bc_max=float(max(abs(pred[0]-1),abs(pred[-1]))),flux_profile=float(np.mean((flux-(c+XX))**2)**.5))
checkpoints=(250,1000,2500);modes=('fixed_0.1','fixed_1','adaptive');rows=[];t0=time.time()
for seed in range(a.start,a.start+a.seeds):
 torch.manual_seed(seed);np.random.seed(seed);random.seed(seed);n=Net();opt=torch.optim.Adam(n.parameters(),lr=.002)
 snapshots={}
 for epoch in range(1,max(checkpoints)+1):
  opt.zero_grad(set_to_none=True);pd_,bc_=losses(n);(pd_+bc_).backward();opt.step()
  if epoch in checkpoints:snapshots[epoch]=(copy.deepcopy(n.state_dict()),copy.deepcopy(opt.state_dict()))
 for start in checkpoints:
  state,adam=snapshots[start]
  for mode in modes:
   nn=Net();nn.load_state_dict(copy.deepcopy(state));oo=torch.optim.Adam(nn.parameters(),lr=.002);oo.load_state_dict(copy.deepcopy(adam));w=.1 if mode=='fixed_0.1' else 1.;hist=[]
   for step in range(a.branch+1):
    lp,lb=losses(nn)
    if mode=='adaptive' and step>0 and (step==1 or step%50==0):
     gp,gb,co=grads(lp,lb,nn);w=.9*w+.1*float(np.clip(gp/(gb+1e-12),.1,1000.))
    if step in (0,a.branch//2,a.branch):
     gp,gb,cos=grads(lp,lb,nn);v=measure(nn);rows.append(dict(seed=seed,checkpoint=start,mode=mode,step=step,total_steps=start+step,weight=w,pde_loss=lp.item(),bc_loss=lb.item(),pde_grad_norm=gp,bc_grad_norm=gb,cosine=cos,weighted_grad_ratio=w*gb/(gp+1e-20),**v))
    if step==a.branch:break
    oo.zero_grad(set_to_none=True);(lp+w*lb).backward();oo.step()
  print(f'seed {seed-a.start+1}/{a.seeds}, start={start}, elapsed={time.time()-t0:.1f}s',flush=True)
R=pd.DataFrame(rows);R.to_csv(out/'measurements.csv',index=False)
final=R[R.step==a.branch];S=final.groupby(['checkpoint','mode']).agg(n=('seed','size'),median_head=('head_l2','median'),mean_head=('head_l2','mean'),median_flux=('flux_cons','median'),median_bc=('bc_max','median'),median_cos=('cosine','median'),median_weight=('weight','median'),median_weighted_grad_ratio=('weighted_grad_ratio','median')).reset_index();S.to_csv(out/'summary.csv',index=False)
# Paired log-error contrasts preserve seed pairing and make causal intervention comparisons
pivot=final.pivot(index=['seed','checkpoint'],columns='mode',values='head_l2');pair=pd.DataFrame({'fixed01_vs_fixed1_logratio':np.log(pivot['fixed_0.1']/pivot['fixed_1']),'adaptive_vs_fixed1_logratio':np.log(pivot['adaptive']/pivot['fixed_1'])}).reset_index();pair.to_csv(out/'paired_log_ratios.csv',index=False)
for metric,label,file in [('head_l2','Relative head L2 error','head_by_checkpoint.png'),('flux_cons','Flux conservation RMSE','flux_by_checkpoint.png'),('cosine','Gradient cosine','gradient_cosine.png')]:
 fig,ax=plt.subplots(figsize=(7,4.5))
 for mode in modes:
  v=final[final['mode']==mode].groupby('checkpoint')[metric].median().reindex(checkpoints);ax.plot(checkpoints,v,'-o',label=mode)
 if metric!='cosine':ax.set_yscale('log')
 else:ax.axhline(0,color='gray',lw=.7)
 ax.set(xlabel='Common pre-intervention checkpoint (epochs)',ylabel=label,title='Effect of intervention timing (paired 10-seed design)');ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(out/file,dpi=160);plt.close(fig)
print('DONE elapsed',round(time.time()-t0,2),'seconds');print(S.to_string(index=False));print('PAIRED');print(pair.groupby('checkpoint').agg(['median','mean']).to_string())
