import argparse, csv, json, math, time
from pathlib import Path
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

class Net(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.net=torch.nn.Sequential(torch.nn.Linear(1,32),torch.nn.Tanh(),torch.nn.Linear(32,32),torch.nn.Tanh(),torch.nn.Linear(32,1))
    def forward(self,x):return self.net(x)

def truth(x):return torch.sin(math.pi*x)+0.2*torch.sin(3*math.pi*x)
def forcing(x):return (math.pi**2)*torch.sin(math.pi*x)+0.2*(3*math.pi)**2*torch.sin(3*math.pi*x)

def run(method,seed,epochs,device):
    torch.manual_seed(seed); torch.set_num_threads(1)
    model=Net().to(device); opt=torch.optim.Adam(model.parameters(),lr=0.002)
    x=torch.linspace(0,1,65,device=device).reshape(-1,1)[1:-1].detach().requires_grad_(True)
    xb=torch.tensor([[0.],[1.]],device=device)
    xt=torch.linspace(0,1,501,device=device).reshape(-1,1)
    # A fixed weight of 1 is intentionally a *baseline*, not an optimized fixed-weight competitor.
    w=1.0; history=[]; start=time.time()
    for ep in range(epochs):
        opt.zero_grad(set_to_none=True)
        u=model(x)
        du=torch.autograd.grad(u,x,torch.ones_like(u),create_graph=True)[0]
        d2=torch.autograd.grad(du,x,torch.ones_like(du),create_graph=True)[0]
        phys=((d2+forcing(x))**2).mean()
        bc=(model(xb)**2).mean()
        if method=='adaptive' and (ep==0 or ep%20==0):
            # Gradient balancing is inspired by established adaptive weighting work;
            # not a faithful implementation of any particular published method.
            gp=torch.autograd.grad(phys,tuple(model.parameters()),retain_graph=True,allow_unused=True)
            gb=torch.autograd.grad(bc,tuple(model.parameters()),retain_graph=True,allow_unused=True)
            np_=sum(float((g.detach()**2).sum()) for g in gp if g is not None)**0.5
            nb_=sum(float((g.detach()**2).sum()) for g in gb if g is not None)**0.5
            target=max(0.1,min(1000.,np_/(nb_+1e-12)))
            w=0.9*w+0.1*target
        (phys+w*bc).backward();opt.step()
        if ep%50==0 or ep==epochs-1:
            with torch.no_grad():
                pred=model(xt); exact=truth(xt)
                rel=float(torch.linalg.vector_norm(pred-exact)/torch.linalg.vector_norm(exact))
            history.append(dict(epoch=ep+1,relative_l2=rel,bc_weight=w,physics_loss=float(phys.detach()),bc_loss=float(bc.detach())))
    with torch.no_grad():
        pred=model(xt);exact=truth(xt)
        rel=float(torch.linalg.vector_norm(pred-exact)/torch.linalg.vector_norm(exact))
        maxerr=float((pred-exact).abs().max())
        bcerr=float(model(xb).abs().max())
        curve=pred.cpu().numpy().ravel().tolist()
    return dict(method=method,seed=seed,epochs=epochs,relative_l2=rel,max_abs_error=maxerr,boundary_error=bcerr,final_bc_weight=w,seconds=round(time.time()-start,2),history=history,curve=curve)

def main():
    p=argparse.ArgumentParser();p.add_argument('--epochs',type=int,default=800);p.add_argument('--seeds',type=int,default=3);p.add_argument('--out',default='results');args=p.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    results=[]
    for seed in range(args.seeds):
        for method in ('fixed','adaptive'):
            r=run(method,seed,args.epochs,'cpu');results.append(r)
            print(method,seed,'rel_L2',round(r['relative_l2'],5),'maxerr',round(r['max_abs_error'],5),'BC',round(r['boundary_error'],5),'s',r['seconds'],flush=True)
    fields=['method','seed','epochs','relative_l2','max_abs_error','boundary_error','final_bc_weight','seconds']
    with (out/'metrics.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{k:r[k] for k in fields} for r in results])
    with (out/'full_results.json').open('w') as f:json.dump(results,f,indent=2)
    fig,ax=plt.subplots(figsize=(7,4))
    for m in ('fixed','adaptive'):
        subset=[r for r in results if r['method']==m]
        traces=np.array([[h['relative_l2'] for h in r['history']] for r in subset]); xx=[h['epoch'] for h in subset[0]['history']]
        ax.plot(xx,np.median(traces,axis=0),label=m);ax.fill_between(xx,np.min(traces,axis=0),np.max(traces,axis=0),alpha=.12)
    ax.set_yscale('log');ax.set_xlabel('Training epoch');ax.set_ylabel('Relative L2 solution error');ax.legend();ax.set_title('PINN: fixed vs gradient-balanced BC loss');fig.tight_layout();fig.savefig(out/'training_error.png',dpi=160);plt.close(fig)
    xx=np.linspace(0,1,501);fig,ax=plt.subplots(figsize=(7,4));ax.plot(xx,np.sin(np.pi*xx)+.2*np.sin(3*np.pi*xx),label='Exact',lw=2)
    for r in results:
        if r['seed']==0:ax.plot(xx,r['curve'],label=f"{r['method']} PINN",alpha=.75)
    ax.set_xlabel('x');ax.set_ylabel('u(x)');ax.legend();ax.set_title('Poisson boundary-value problem');fig.tight_layout();fig.savefig(out/'solution.png',dpi=160);plt.close(fig)
    for m in ('fixed','adaptive'):
        vals=[r['relative_l2'] for r in results if r['method']==m]
        print('SUMMARY',m,'median rel L2',np.median(vals),'range',min(vals),max(vals))
if __name__=='__main__':main()
