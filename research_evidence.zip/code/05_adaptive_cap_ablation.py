"""Mechanism ablation: original adaptive versus constrained adaptive weighting.
Uses groundwater_loss_sweep.py physics, seeds and architecture; standalone code.
Run: python groundwater_mechanism_test.py --epochs 2500 --seeds 0 1 2
"""
import argparse, math, random, time
from pathlib import Path
import numpy as np, pandas as pd, torch
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=argparse.ArgumentParser();P.add_argument('--epochs',type=int,default=2500);P.add_argument('--seeds',type=int,nargs='+',default=[0,1,2]);P.add_argument('--out',default='/mnt/data/groundwater_mechanism_results');P.add_argument('--methods',nargs='+',default=['fixed_0.1','adaptive_original','adaptive_cap_0.1','adaptive_cap_1.0']);args=P.parse_args()
O=Path(args.out);O.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(1)
C=100.; T=.04; SRC=1.; xs=np.linspace(0,1,1001)
def kn(x):
 s=1/(1+np.exp(-np.clip((np.asarray(x)-.5)/T,-50,50)));return np.exp(-math.log(C)*s)
def kt(x):
 s=torch.sigmoid((x-.5)/T); k=torch.exp(-math.log(C)*s);kp=-math.log(C)/T*s*(1-s)*k;return k,kp
def reference(x):
 xx=np.linspace(0,1,40001); inv=1/kn(xx); A=np.trapezoid(inv,xx);B=np.trapezoid(xx*inv,xx); c=(1-B)/A
 g=(c+xx)*inv; integral=np.r_[0,np.cumsum((g[1:]+g[:-1])*.5*np.diff(xx))];return 1-np.interp(x,xx,integral),c
true,c=reference(xs)
class Net(torch.nn.Module):
 def __init__(self):
  super().__init__();self.net=torch.nn.Sequential(torch.nn.Linear(1,32),torch.nn.Tanh(),torch.nn.Linear(32,32),torch.nn.Tanh(),torch.nn.Linear(32,1))
 def forward(self,x):return self.net(x)
def norms(loss,model):
 g=torch.autograd.grad(loss,list(model.parameters()),retain_graph=True,allow_unused=True);return math.sqrt(sum((v.detach()**2).sum().item() for v in g if v is not None)+1e-24)
def measure(model):
 x=torch.tensor(xs[:,None],dtype=torch.float32,requires_grad=True);p=model(x);px=torch.autograd.grad(p,x,torch.ones_like(p))[0].detach().numpy().ravel();h=p.detach().numpy().ravel();q=-kn(xs)*px
 qprime=np.gradient(q,xs,edge_order=2)
 return dict(relative_l2=float(np.linalg.norm(h-true)/np.linalg.norm(true)),bc_max=float(max(abs(h[0]-1),abs(h[-1]))),flux_conservation_rmse=float(np.sqrt(np.mean((qprime[1:-1]-1)**2))),flux_reference_rmse=float(np.sqrt(np.mean((q-(c+xs))**2))))
methods=args.methods
rows=[];history=[]
for seed in args.seeds:
 for method in methods:
  random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);net=Net();opt=torch.optim.Adam(net.parameters(),lr=.002)
  x=torch.linspace(0,1,82)[1:-1,None].clone().detach().requires_grad_(True);xb=torch.tensor([[0.],[1.]]);yb=torch.tensor([[1.],[0.]])
  w=.1 if method in ('fixed_0.1','adaptive_cap_0.1','adaptive_cap_1.0') else 1.
  start=time.perf_counter()
  for e in range(1,args.epochs+1):
   opt.zero_grad(set_to_none=True);h=net(x);hx=torch.autograd.grad(h,x,torch.ones_like(h),create_graph=True)[0];hxx=torch.autograd.grad(hx,x,torch.ones_like(hx),create_graph=True)[0];k,kp=kt(x)
   pde=(-(k*hxx+kp*hx)-1).square().mean();bc=(net(xb)-yb).square().mean()
   if method!='fixed_0.1' and (e==1 or e%50==0):
    gp=norms(pde,net);gb=norms(bc,net);target=np.clip(gp/(gb+1e-12),.1,1000.)
    if method=='adaptive_cap_0.1':target=min(target,.1)
    if method=='adaptive_cap_1.0':target=min(target,1.)
    w=.9*w+.1*float(target)
   (pde+w*bc).backward();opt.step()
   if e in (1,250,500,1200,args.epochs) or e%100==0:
    hrow=dict(seed=seed,method=method,epoch=e,weight=w,pde_loss=pde.item(),bc_loss=bc.item());history.append(hrow)
   if e in (250,500,1200,args.epochs):
    rows.append(dict(seed=seed,method=method,epoch=e,weight=w,elapsed_sec=time.perf_counter()-start,**measure(net)))
  print('finished',seed,method,rows[-1]['relative_l2'],rows[-1]['flux_conservation_rmse'],round(w,4),flush=True)
R=pd.DataFrame(rows);H=pd.DataFrame(history);R.to_csv(O/'metrics.csv',index=False);H.to_csv(O/'weight_and_loss_history.csv',index=False)
S=R[R.epoch==args.epochs].groupby('method').agg(median_head_error=('relative_l2','median'),median_flux_conservation=('flux_conservation_rmse','median'),median_boundary_error=('bc_max','median'),median_weight=('weight','median'),median_elapsed=('elapsed_sec','median'))
S.to_csv(O/'summary.csv');print('\n'+S.to_string())
fig,ax=plt.subplots(figsize=(8,4))
for method in methods:
 g=H[H.method==method].groupby('epoch').weight.median();ax.plot(g.index,g.values,label=method)
ax.set(xlabel='Epoch',ylabel='Median boundary-loss weight',title='Adaptive boundary weight trajectories');ax.legend(fontsize=8);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(O/'weight_trajectories.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4))
for method in methods:
 g=R[R.method==method].groupby('epoch').relative_l2.median();ax.plot(g.index,g.values,'-o',label=method)
ax.set(xlabel='Epoch',ylabel='Median relative head error',title='Controlled adaptive-weight ablation');ax.set_yscale('log');ax.legend(fontsize=8);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(O/'error_vs_epochs.png',dpi=150);plt.close(fig)
