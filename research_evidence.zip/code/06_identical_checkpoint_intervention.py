"""Checkpoint intervention: identical network and Adam state, different loss-weight policy.
Run: python groundwater_branch_intervention.py --seeds 0 1 2 --warmup 500 --branch 1200
"""
import argparse, copy, math, random, time
from pathlib import Path
import numpy as np, pandas as pd, torch
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=argparse.ArgumentParser();P.add_argument('--seeds',nargs='+',type=int,default=[0,1,2]);P.add_argument('--warmup',type=int,default=500);P.add_argument('--branch',type=int,default=1200);P.add_argument('--out',default='/mnt/data/groundwater_branch_results');a=P.parse_args()
O=Path(a.out);O.mkdir(exist_ok=True,parents=True);torch.set_num_threads(1)
C=100.;T=.04; xs=np.linspace(0.,1.,1001)
def kn(x):
 s=1/(1+np.exp(-np.clip((np.asarray(x)-.5)/T,-50,50)));return np.exp(-math.log(C)*s)
def kt(x):
 s=torch.sigmoid((x-.5)/T);k=torch.exp(-math.log(C)*s);return k,-math.log(C)/T*s*(1-s)*k
xx=np.linspace(0,1,40001); inv=1/kn(xx); const=(1-np.trapezoid(xx*inv,xx))/np.trapezoid(inv,xx)
yy=np.r_[0,np.cumsum((const+xx[1:])*inv[1:]*np.diff(xx)/2 + (const+xx[:-1])*inv[:-1]*np.diff(xx)/2)];true=1-np.interp(xs,xx,yy)
class Net(torch.nn.Module):
 def __init__(self):
  super().__init__();self.net=torch.nn.Sequential(torch.nn.Linear(1,32),torch.nn.Tanh(),torch.nn.Linear(32,32),torch.nn.Tanh(),torch.nn.Linear(32,1))
 def forward(self,x):return self.net(x)
x=torch.linspace(0,1,82)[1:-1,None].detach().requires_grad_(True);xb=torch.tensor([[0.],[1.]]);yb=torch.tensor([[1.],[0.]])
def losses(net):
 h=net(x); hx=torch.autograd.grad(h,x,torch.ones_like(h),create_graph=True)[0];hxx=torch.autograd.grad(hx,x,torch.ones_like(hx),create_graph=True)[0];k,kp=kt(x)
 return (-(k*hxx+kp*hx)-1).square().mean(),(net(xb)-yb).square().mean()
def grad_info(pde,bc,net):
 pars=list(net.parameters());ga=torch.autograd.grad(pde,pars,retain_graph=True,allow_unused=True);gb=torch.autograd.grad(bc,pars,retain_graph=True,allow_unused=True)
 va=torch.cat([(g.detach() if g is not None else torch.zeros_like(p)).flatten() for g,p in zip(ga,pars)]);vb=torch.cat([(g.detach() if g is not None else torch.zeros_like(p)).flatten() for g,p in zip(gb,pars)]);na=va.norm().item();nb=vb.norm().item();cos=torch.dot(va,vb).item()/(na*nb+1e-20)
 return na,nb,cos

def measure(net):
 xx0=torch.tensor(xs[:,None],dtype=torch.float32,requires_grad=True);h=net(xx0);hp=torch.autograd.grad(h,xx0,torch.ones_like(h))[0].detach().numpy().ravel();prediction=h.detach().numpy().ravel();q=-kn(xs)*hp
 return dict(head_relative_l2=np.linalg.norm(prediction-true)/np.linalg.norm(true),bc_max=max(abs(prediction[0]-1),abs(prediction[-1])),flux_conservation_rmse=np.sqrt(np.mean((np.gradient(q,xs,edge_order=2)[1:-1]-1)**2)),flux_reference_rmse=np.sqrt(np.mean((q-(const+xs))**2)))
records=[];runs=[]
for seed in a.seeds:
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);net=Net();opt=torch.optim.Adam(net.parameters(),lr=.002)
 for t in range(a.warmup):
  opt.zero_grad(set_to_none=True);p,b=losses(net);(p+b).backward();opt.step()
 state=copy.deepcopy(net.state_dict());adam=copy.deepcopy(opt.state_dict())
 print('shared seed',seed,'warmup',a.warmup,'error',measure(net)['head_relative_l2'],flush=True)
 for mode in ['fixed_0.1','fixed_1','adaptive']:
  net2=Net();net2.load_state_dict(copy.deepcopy(state));optim=torch.optim.Adam(net2.parameters(),lr=.002);optim.load_state_dict(copy.deepcopy(adam));w=1. if mode!='fixed_0.1' else .1
  for t in range(a.branch+1):
   p,b=losses(net2)
   monitor=(t in [0,1,50,100,250,500,800,a.branch] or (t%100==0))
   if mode=='adaptive' and t>0 and (t==1 or t%50==0):
    gp,gb,cos=grad_info(p,b,net2);w=.9*w+.1*float(np.clip(gp/(gb+1e-12),.1,1000))
   if monitor:
    gp,gb,cos=grad_info(p,b,net2);m=measure(net2)
    records.append(dict(seed=seed,mode=mode,branch_epoch=t,total_epoch=a.warmup+t,weight=w,pde_loss=p.item(),bc_loss=b.item(),pde_grad_norm=gp,bc_grad_norm=gb,gradient_cosine=cos,weighted_boundary_to_pde_grad_norm=w*gb/(gp+1e-20),**m))
   if t==a.branch:break
   optim.zero_grad(set_to_none=True);(p+w*b).backward();optim.step()
  print('finished',seed,mode,'head',round(m['head_relative_l2'],6),'flux',round(m['flux_conservation_rmse'],6),'w',round(w,4),flush=True)
R=pd.DataFrame(records);R.to_csv(O/'checkpoint_metrics.csv',index=False)
S=R[R.branch_epoch==a.branch].groupby('mode').agg(n=('seed','count'),median_head=('head_relative_l2','median'),median_flux=('flux_conservation_rmse','median'),median_bc=('bc_max','median'),median_weight=('weight','median'),median_grad_cos=('gradient_cosine','median'),median_weighted_grad_ratio=('weighted_boundary_to_pde_grad_norm','median'));S.to_csv(O/'summary.csv');print(S.to_string())
fig,ax=plt.subplots(figsize=(8,5));
for mode,g in R.groupby('mode'):
 v=g.groupby('branch_epoch').head_relative_l2.median();ax.plot(v.index,v.values,'-o',markersize=3,label=mode)
ax.set(yscale='log',xlabel='Training steps after shared checkpoint',ylabel='Median relative hydraulic-head error',title='Checkpoint-controlled weighting intervention');ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(O/'head_error_trajectories.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,5))
for mode,g in R.groupby('mode'):
 v=g.groupby('branch_epoch').gradient_cosine.median();ax.plot(v.index,v.values,'-o',markersize=3,label=mode)
ax.axhline(0,color='black',lw=1);ax.set(xlabel='Steps after shared checkpoint',ylabel='PDE vs boundary gradient cosine',title='Gradient alignment (negative means conflict)');ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(O/'gradient_alignment.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,5))
for mode,g in R.groupby('mode'):
 v=g.groupby('branch_epoch').weighted_boundary_to_pde_grad_norm.median();ax.plot(v.index,v.values,'-o',markersize=3,label=mode)
ax.set(yscale='log',xlabel='Steps after shared checkpoint',ylabel='Weighted boundary / PDE gradient norm',title='Effective gradient pressure from boundary constraint');ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(O/'weighted_gradient_ratio.png',dpi=160);plt.close(fig)
