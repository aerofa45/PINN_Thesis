import nbformat,os
n=nbformat.read('/mnt/data/Project2_Groundwater_PINN_Colab.ipynb',as_version=4)
os.chdir('/mnt/data')
for i in [1,3,5,7]:
 s=n.cells[i].source
 if i==3:
  s=s.replace('CONTRASTS = [1.0, 10.0, 100.0]','CONTRASTS = [100.0]').replace('SEEDS = [0, 1, 2]','SEEDS = [0, 1]').replace('EPOCHS = 1200','EPOCHS = 5000')
 exec(compile(s,'cell'+str(i),'exec'),globals())
s=n.cells[8].source
s=s[:s.index('results=[];histories=[];predictions={}')]
exec(compile(s,'training_fn','exec'),globals())
for seed in SEEDS:
 for method in ['fixed','adaptive']:
  metrics,history,pred=train_one(100.0,seed,method)
  print('diagnostic',metrics,flush=True)
