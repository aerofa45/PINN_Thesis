# Checkpoint-controlled PINN loss-weight intervention, exploratory report

Date: 2026-10-07/08, experimental, synthetic steady 1D groundwater flow, non-peer reviewed

## Question

With the network, collocation points, and Adam optimizer state held at a common intermediate checkpoint, what difference do boundary-loss weights of 0.1, 1 and gradient-norm adaptive weighting make to hydraulic-head accuracy, flux conservation and gradient alignment?

## Model and intervention
`-(k(x)h'(x))'=1`, `h(0)=1`, `h(1)=0`, with `k(x)=exp[-log(100) sigmoid((x-0.5)/0.04)]`. Smooth transition between geological layers, not a discontinuous physical interface. Two tanh hidden layers of 32 units; 80 collocation points, Adam learning rate 0.002. Seeds 0, 1, 2. For each seed, 500 shared epochs of fixed `lambda_BC=1`, save **identical network AND Adam state**. Clone and branch for 1,200 additional epochs with: fixed 0.1, fixed 1, adaptive weight. Adaptive weight initialized at 1 and updated at first branch step and every 50 steps: `w <- 0.9*w + 0.1*clip(||grad PDE||/||grad BC||,0.1,1000)`.

## Median results across 3 paired seeds at branch step 1200
| Branch | Rel. L2 head error | Flux conservation RMSE | Boundary max error | PDE/BC gradient cosine | final weight |
|---|---:|---:|---:|---:|---:|
| fixed 0.1 | 0.100571 | 0.162618 | 0.156970 | -0.088695 | 0.1 |
| fixed 1 | 0.076545 | 0.174533 | 0.013938 | -0.944127 | 1 |
| adaptive | 0.096243 | 0.192540 | 0.003034 | -0.995603 | 2.457591 |

## Interpretation

The adaptive weight achieved smallest boundary error but largest median conservation error, and almost opposite PDE/BC gradients on the last checkpoint. The fixed-0.1 branch had weakest final gradient opposition and best median conservation, but very large boundary error. Fixed-1 produced the lowest median head error. So fixed 0.1 is not always better, and this experiment does not prove simple boundary overweighting is the sole problem. The result is different from training from random initialization independently: training history and optimizer state matter.

A negative cosine quantifies conflict in the parameter gradients, but it doesn't by itself prove the conflicts caused the accuracy degradation nor a converged solution. The weight-to-gradient-ratio evaluates effective gradient pressure; absolute weight magnitudes can be misleading.

## Limitations

Only three seeds, one smooth 1D conductivity profile, one common warmup duration and branching horizon, limited hyperparameters, no significance test, and no established adaptive baseline. It is a causal comparison of training interventions from an identical state (within each seed), but the mechanism by which gradient conflict affects model error is hypothetical. The Adam moments are cloned; the gradient outcomes evolve as the methods diverge. Important: starting from a fixed-1 checkpoint may favor that policy, and switching to 0.1 can be initially detrimental to boundary satisfaction. Run the branches at 250/1000/2500 common warmup checkpoints, longer branch durations with 10+ paired seeds, and test hard boundary enforcement and loss normalization.

## Artifacts
- `groundwater_branch_intervention.py`: complete runnable code.
- `checkpoint_metrics.csv`: every saved checkpoint and all measured quantities.
- `summary.csv`: aggregated results.
- `head_error_trajectories.png`, `gradient_alignment.png`, `weighted_gradient_ratio.png`: figures.

## Reproduction
`pip install torch numpy pandas matplotlib`
`python groundwater_branch_intervention.py --seeds 0 1 2 --warmup 500 --branch 1200 --out results`
